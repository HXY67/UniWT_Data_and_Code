# UniWT-YOLO source

- Training: python train_uniwt_yolo.py --help
- Prediction: python predict_uniwt_yolo.py --help
- Regional inference: python predict_uniwt_yolo_regional.py --help
- GeoTIFF sliding-window inference: python predict_uniwt_yolo_geotiff.py --help

Run from this directory. Set dataset and checkpoint paths for your environment. The model architecture is in configs/uniwt_yolo_architecture.yaml. Training data and checkpoints are separate.
