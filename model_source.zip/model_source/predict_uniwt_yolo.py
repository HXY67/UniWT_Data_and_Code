"""Predict native-size 3-channel offshore or 7-channel land TIFF patches."""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import cv2
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from unified_wt.modules import register_unified_components  # noqa: E402

register_unified_components()

from ultralytics import YOLO  # noqa: E402
from ultralytics.utils.patches import imread  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Band-order-safe unified wind-turbine prediction")
    parser.add_argument("--weights", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True, help="One TIFF or a directory of TIFF patches")
    parser.add_argument("--scene", choices=("land", "offshore"), required=True)
    parser.add_argument("--imgsz", type=int, default=None, help="Default: land=256, offshore=512")
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--iou", type=float, default=0.7)
    parser.add_argument("--max-det", type=int, default=300)
    parser.add_argument("--device", default="0")
    parser.add_argument("--output", type=Path, default=ROOT / "runs" / "unified_prediction" / "predictions.csv")
    return parser.parse_args()


def collect_images(source: Path) -> list[Path]:
    if source.is_file():
        return [source]
    if not source.is_dir():
        raise FileNotFoundError(source)
    files = sorted([*source.rglob("*.tif"), *source.rglob("*.tiff")])
    if not files:
        raise FileNotFoundError(f"No .tif/.tiff images found under {source}")
    return files


def load_uint8_band_stack(path: Path, scene: str, expected_channels: int) -> np.ndarray:
    image = imread(str(path))
    if image is None:
        raise ValueError(f"Unable to read {path}")
    if image.ndim == 2:
        image = image[..., None]
    if image.ndim != 3 or image.shape[2] != expected_channels:
        raise ValueError(
            f"{path} has shape {image.shape}; expected HWC with {expected_channels} channels."
        )
    if not np.isfinite(image).all():
        raise ValueError(f"{path} contains NaN or Inf values.")
    if image.min() < 0 or image.max() > 255:
        raise ValueError(
            f"{path} is outside the trained 0-255 range. Apply the same stretch used for training before inference."
        )
    image = image.astype(np.uint8, copy=False)
    # The user's offshore files are single-page RGB TIFFs. OpenCV returns BGR,
    # while the trained RGB route expects Sentinel-2 [B4, B3, B2]. Land TIFFs
    # are seven grayscale pages and must retain their page order.
    if scene == "offshore":
        image = np.ascontiguousarray(image[..., ::-1])
    return image


def letterbox_tensor(image: np.ndarray, imgsz: int) -> tuple[torch.Tensor, float, float, float]:
    height, width = image.shape[:2]
    ratio = min(imgsz / height, imgsz / width)
    resized_width = round(width * ratio)
    resized_height = round(height * ratio)
    if (resized_width, resized_height) != (width, height):
        image = cv2.resize(image, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR)
        if image.ndim == 2:
            image = image[..., None]

    pad_x = (imgsz - resized_width) / 2.0
    pad_y = (imgsz - resized_height) / 2.0
    left = round(pad_x - 0.1)
    top = round(pad_y - 0.1)
    canvas = np.full((imgsz, imgsz, image.shape[2]), 114, dtype=np.uint8)
    canvas[top : top + resized_height, left : left + resized_width] = image

    tensor = torch.from_numpy(np.ascontiguousarray(canvas.transpose(2, 0, 1))).float().unsqueeze(0) / 255.0
    return tensor, ratio, float(left), float(top)


def restore_boxes(boxes: np.ndarray, ratio: float, pad_x: float, pad_y: float, width: int, height: int) -> np.ndarray:
    if not len(boxes):
        return boxes
    boxes[:, [0, 2]] = (boxes[:, [0, 2]] - pad_x) / ratio
    boxes[:, [1, 3]] = (boxes[:, [1, 3]] - pad_y) / ratio
    boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, width)
    boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, height)
    return boxes


def main() -> None:
    args = parse_args()
    if not args.weights.is_file():
        raise FileNotFoundError(args.weights)
    expected_channels = 7 if args.scene == "land" else 3
    imgsz = args.imgsz or (256 if args.scene == "land" else 512)
    if imgsz % 32:
        raise ValueError(f"imgsz must be a multiple of 32, got {imgsz}")
    files = collect_images(args.source)
    model = YOLO(str(args.weights.resolve()))

    rows = []
    for path in files:
        image = load_uint8_band_stack(path, args.scene, expected_channels)
        height, width = image.shape[:2]
        tensor, ratio, pad_x, pad_y = letterbox_tensor(image, imgsz)
        result = model.predict(
            source=tensor,
            conf=args.conf,
            iou=args.iou,
            max_det=args.max_det,
            device=args.device,
            verbose=False,
        )[0]
        if result.boxes is None or len(result.boxes) == 0:
            continue

        boxes = restore_boxes(result.boxes.xyxy.detach().cpu().numpy().copy(), ratio, pad_x, pad_y, width, height)
        confidences = result.boxes.conf.detach().cpu().numpy()
        classes = result.boxes.cls.detach().cpu().numpy().astype(int)
        for box, confidence, class_id in zip(boxes, confidences, classes):
            x1, y1, x2, y2 = map(float, box)
            box_width = max(x2 - x1, 0.0)
            box_height = max(y2 - y1, 0.0)
            rows.append(
                {
                    "image": str(path.resolve()),
                    "scene": args.scene,
                    "class_id": class_id,
                    "confidence": float(confidence),
                    "x1_px": x1,
                    "y1_px": y1,
                    "x2_px": x2,
                    "y2_px": y2,
                    "x_center_norm": ((x1 + x2) / 2.0) / width,
                    "y_center_norm": ((y1 + y2) / 2.0) / height,
                    "width_norm": box_width / width,
                    "height_norm": box_height / height,
                }
            )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "image",
        "scene",
        "class_id",
        "confidence",
        "x1_px",
        "y1_px",
        "x2_px",
        "y2_px",
        "x_center_norm",
        "y_center_norm",
        "width_norm",
        "height_norm",
    ]
    with args.output.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Processed {len(files)} images; detections={len(rows)}; saved={args.output.resolve()}")


if __name__ == "__main__":
    main()
