"""Sliding-window inference on large land/offshore GeoTIFFs with final UniWT-YOLO.

The raster is read window by window; no temporary image tiles are written.
Land source band order: B4, B3, B2, B8, B12, VV, VH (7 bands).
Offshore source may contain B4, B3, B2 (3 bands) or
B4, B3, B2, B8, B12 (5 bands); only its first three RGB bands are read.
By default, raw float mosaics are converted with the fixed stretch recovered
from the training-set conversion script. Use --input-mode uint8 only for
rasters already converted with that same stretch.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import rasterio
import torch
from rasterio.windows import Window
from rasterio.warp import transform as crs_transform


ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from unified_wt.modules import register_unified_components  # noqa: E402

register_unified_components()

from ultralytics import YOLO, __version__ as ultralytics_version  # noqa: E402


TIFF_SUFFIXES = {".tif", ".tiff"}
BAND_ORDERS = {
    "land": ["B4", "B3", "B2", "B8", "B12", "VV", "VH"],
    "offshore": ["B4", "B3", "B2"],
}
LAND_OPTICAL_CLIP_MAX = np.asarray([0.30, 0.30, 0.30, 0.40, 0.30], dtype=np.float32)[:, None, None]
LAND_SAR_MIN = np.asarray([-25.0, -32.0], dtype=np.float32)[:, None, None]
LAND_SAR_MAX = np.asarray([5.0, 0.0], dtype=np.float32)[:, None, None]
OFFSHORE_OPTICAL_CLIP_MAX = np.asarray([0.30, 0.30, 0.30], dtype=np.float32)[:, None, None]
FIELDS = [
    "raster",
    "scene",
    "window_id",
    "window_col",
    "window_row",
    "class_id",
    "confidence",
    "x1_px",
    "y1_px",
    "x2_px",
    "y2_px",
    "x_center_px",
    "y_center_px",
    "width_px",
    "height_px",
    "x_map",
    "y_map",
    "longitude",
    "latitude",
    "source_crs",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Final UniWT-YOLO sliding-window inference for large land/offshore GeoTIFFs"
    )
    parser.add_argument("--weights", type=Path, required=True, help="Final UniWT-YOLO best.pt")
    parser.add_argument(
        "--land-source",
        type=Path,
        default=None,
        help="Optional folder of large 7-band land GeoTIFFs",
    )
    parser.add_argument(
        "--offshore-source",
        type=Path,
        default=None,
        help="Folder of large offshore GeoTIFFs (3-band RGB or 5-band S2 with RGB first)",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--tile-size", type=int, default=256)
    parser.add_argument("--stride", type=int, default=192)
    parser.add_argument("--land-conf", type=float, default=0.10)
    parser.add_argument("--offshore-conf", type=float, default=0.10)
    parser.add_argument("--tile-iou", type=float, default=0.50, help="NMS IoU inside each window")
    parser.add_argument(
        "--global-iou",
        type=float,
        default=0.45,
        help="Global NMS IoU used to remove duplicates from overlapping windows",
    )
    parser.add_argument("--max-det", type=int, default=300)
    parser.add_argument("--device", default="0")
    parser.add_argument(
        "--input-mode",
        choices=("raw", "uint8"),
        default="raw",
        help="raw applies the fixed training stretch; uint8 expects already converted 0-255 rasters",
    )
    parser.add_argument(
        "--edge-margin",
        type=int,
        default=0,
        help="Optionally reject box centres this many pixels from an internal window edge",
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Log a failed raster/window and continue",
    )
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if not args.weights.is_file():
        raise FileNotFoundError(f"Weights not found: {args.weights}")
    if args.land_source is None and args.offshore_source is None:
        raise ValueError("Supply --land-source and/or --offshore-source")
    if args.land_source is not None and not args.land_source.exists():
        raise FileNotFoundError(f"Land source not found: {args.land_source}")
    if args.offshore_source is not None and not args.offshore_source.exists():
        raise FileNotFoundError(f"Offshore source not found: {args.offshore_source}")
    if args.tile_size <= 0 or args.tile_size % 32:
        raise ValueError("--tile-size must be a positive multiple of 32")
    if args.stride <= 0 or args.stride > args.tile_size:
        raise ValueError("--stride must be in (0, tile-size]")
    if args.edge_margin < 0 or args.edge_margin * 2 >= args.tile_size:
        raise ValueError("--edge-margin is invalid")
    for name in ("land_conf", "offshore_conf", "tile_iou", "global_iou"):
        value = float(getattr(args, name))
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"--{name.replace('_', '-')} must be in [0, 1]")


def collect_rasters(source: Path) -> list[Path]:
    if source.is_file():
        if source.suffix.lower() not in TIFF_SUFFIXES:
            raise ValueError(f"Not a TIFF: {source}")
        return [source]
    rasters = sorted(
        path for path in source.rglob("*") if path.is_file() and path.suffix.lower() in TIFF_SUFFIXES
    )
    if not rasters:
        raise FileNotFoundError(f"No TIFF files found under: {source}")
    return rasters


def sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sliding_positions(length: int, tile: int, stride: int) -> list[int]:
    """Cover the complete raster and align the last window with the far edge."""
    if length <= tile:
        return [0]
    positions = list(range(0, length - tile + 1, stride))
    last = length - tile
    if positions[-1] != last:
        positions.append(last)
    return positions


def read_window_uint8(
    dataset: rasterio.io.DatasetReader,
    col: int,
    row: int,
    tile: int,
    expected_channels: int,
    scene: str,
    input_mode: str,
) -> tuple[np.ndarray, bool]:
    valid_width = min(tile, dataset.width - col)
    valid_height = min(tile, dataset.height - row)
    data = dataset.read(
        indexes=list(range(1, expected_channels + 1)),
        window=Window(col, row, valid_width, valid_height),
        boundless=False,
        masked=True,
    )
    if data.shape[0] != expected_channels:
        raise ValueError(f"read {data.shape[0]} bands; expected {expected_channels}")
    # Large mosaics commonly contain NaN/Inf or an explicit NoData mask along
    # their footprint boundary. Completely invalid windows are skipped. In a
    # partially valid window, invalid pixels are filled with 0, matching the
    # background convention used by the uint8 training mosaics.
    values = np.asarray(data.data)
    invalid = np.ma.getmaskarray(data) | ~np.isfinite(values)
    all_invalid = bool(invalid.all())
    if all_invalid:
        return np.zeros((expected_channels, tile, tile), dtype=np.uint8), True

    clean_float = np.where(invalid, 0, values).astype(np.float32, copy=False)
    if input_mode == "raw":
        if scene == "land":
            optical = np.clip(clean_float[:5], 0.0, LAND_OPTICAL_CLIP_MAX)
            optical = optical / (LAND_OPTICAL_CLIP_MAX + 1e-6)
            sar = np.clip(clean_float[5:7], LAND_SAR_MIN, LAND_SAR_MAX)
            sar = (sar - LAND_SAR_MIN) / (LAND_SAR_MAX - LAND_SAR_MIN + 1e-6)
            normalized = np.concatenate((optical, sar), axis=0)
        else:
            normalized = np.clip(clean_float[:3], 0.0, OFFSHORE_OPTICAL_CLIP_MAX)
            normalized = normalized / (OFFSHORE_OPTICAL_CLIP_MAX + 1e-6)
        clean = np.clip(normalized * 255.0, 0, 255).astype(np.uint8)
        # Invalid pixels must stay background zero after the SAR offset mapping.
        clean[invalid] = 0
    else:
        valid_values = values[~invalid]
        minimum, maximum = float(valid_values.min()), float(valid_values.max())
        if minimum < 0 or maximum > 255:
            raise ValueError(
                f"valid-pixel range is [{minimum}, {maximum}], but --input-mode uint8 "
                "requires [0, 255]. Use --input-mode raw for the original float mosaics."
            )
        clean = clean_float.astype(np.uint8)
    padded = np.full((expected_channels, tile, tile), 114, dtype=np.uint8)
    padded[:, :valid_height, :valid_width] = clean
    return padded, False


def window_is_empty(chw: np.ndarray, nodata: float | None) -> bool:
    if nodata is not None and np.all(chw == nodata):
        return True
    # All-zero windows are usually outside the valid mosaic footprint.
    return not np.any(chw)


def box_iou_one_to_many(box: np.ndarray, boxes: np.ndarray) -> np.ndarray:
    x1 = np.maximum(box[0], boxes[:, 0])
    y1 = np.maximum(box[1], boxes[:, 1])
    x2 = np.minimum(box[2], boxes[:, 2])
    y2 = np.minimum(box[3], boxes[:, 3])
    intersection = np.maximum(x2 - x1, 0.0) * np.maximum(y2 - y1, 0.0)
    area_a = max(box[2] - box[0], 0.0) * max(box[3] - box[1], 0.0)
    area_b = np.maximum(boxes[:, 2] - boxes[:, 0], 0.0) * np.maximum(
        boxes[:, 3] - boxes[:, 1], 0.0
    )
    return intersection / np.maximum(area_a + area_b - intersection, 1e-12)


def global_nms(rows: list[dict], iou_threshold: float) -> list[dict]:
    """Class-aware NMS in full-raster pixel coordinates."""
    if not rows:
        return []
    kept: list[dict] = []
    class_ids = sorted({int(row["class_id"]) for row in rows})
    for class_id in class_ids:
        candidates = [row for row in rows if int(row["class_id"]) == class_id]
        boxes = np.asarray(
            [[r["x1_px"], r["y1_px"], r["x2_px"], r["y2_px"]] for r in candidates],
            dtype=np.float64,
        )
        scores = np.asarray([r["confidence"] for r in candidates], dtype=np.float64)
        order = scores.argsort()[::-1]
        while order.size:
            best = int(order[0])
            kept.append(candidates[best])
            if order.size == 1:
                break
            remaining = order[1:]
            overlaps = box_iou_one_to_many(boxes[best], boxes[remaining])
            order = remaining[overlaps <= iou_threshold]
    kept.sort(key=lambda row: (row["raster"], -float(row["confidence"])))
    return kept


def add_coordinates(rows: list[dict], dataset: rasterio.io.DatasetReader) -> None:
    if not rows:
        return
    xs, ys = [], []
    for row in rows:
        x, y = dataset.transform * (row["x_center_px"], row["y_center_px"])
        xs.append(float(x))
        ys.append(float(y))
        row["x_map"] = float(x)
        row["y_map"] = float(y)
        row["source_crs"] = dataset.crs.to_string() if dataset.crs else ""
    if dataset.crs:
        if dataset.crs.to_epsg() == 4326:
            lons, lats = xs, ys
        else:
            lons, lats = crs_transform(dataset.crs, "EPSG:4326", xs, ys)
        for row, lon, lat in zip(rows, lons, lats):
            row["longitude"] = float(lon)
            row["latitude"] = float(lat)
    else:
        for row in rows:
            row["longitude"] = ""
            row["latitude"] = ""


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_geojson(path: Path, rows: list[dict], scene: str) -> None:
    features = []
    for row in rows:
        if row.get("longitude", "") == "" or row.get("latitude", "") == "":
            continue
        properties = {
            key: value
            for key, value in row.items()
            if key not in {"longitude", "latitude", "x_map", "y_map"}
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [float(row["longitude"]), float(row["latitude"])],
                },
                "properties": properties,
            }
        )
    collection = {
        "type": "FeatureCollection",
        "name": f"E4_{scene}_wind_turbine_candidates",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
        "features": features,
    }
    path.write_text(json.dumps(collection, ensure_ascii=False), encoding="utf-8")


def process_raster(
    model: YOLO,
    path: Path,
    scene: str,
    args: argparse.Namespace,
) -> tuple[list[dict], dict]:
    rows: list[dict] = []
    start = time.perf_counter()
    confidence_threshold = args.land_conf if scene == "land" else args.offshore_conf
    with rasterio.open(path) as dataset:
        expected_channels = 7 if scene == "land" else 3
        if scene == "land" and dataset.count != 7:
            raise ValueError(f"{path} has {dataset.count} bands; land expects exactly 7")
        if scene == "offshore" and dataset.count not in {3, 5}:
            raise ValueError(
                f"{path} has {dataset.count} bands; offshore source must have either "
                "3 bands [B4,B3,B2] or 5 bands [B4,B3,B2,B8,B12]"
            )
        columns = sliding_positions(dataset.width, args.tile_size, args.stride)
        rows_pos = sliding_positions(dataset.height, args.tile_size, args.stride)
        total_windows = len(columns) * len(rows_pos)
        processed_windows = 0
        empty_windows = 0

        for row_index, top in enumerate(rows_pos):
            for col_index, left in enumerate(columns):
                window_id = row_index * len(columns) + col_index
                chw, all_invalid = read_window_uint8(
                    dataset,
                    left,
                    top,
                    args.tile_size,
                    expected_channels,
                    scene,
                    args.input_mode,
                )
                if all_invalid or window_is_empty(chw, dataset.nodata):
                    empty_windows += 1
                    continue
                tensor = torch.from_numpy(chw).float().unsqueeze(0) / 255.0
                result = model.predict(
                    source=tensor,
                    imgsz=args.tile_size,
                    conf=confidence_threshold,
                    iou=args.tile_iou,
                    max_det=args.max_det,
                    device=args.device,
                    verbose=False,
                )[0]
                processed_windows += 1
                if result.boxes is not None and len(result.boxes):
                    boxes = result.boxes.xyxy.detach().cpu().numpy()
                    scores = result.boxes.conf.detach().cpu().numpy()
                    classes = result.boxes.cls.detach().cpu().numpy().astype(int)
                    for box, score, class_id in zip(boxes, scores, classes):
                        x1_local, y1_local, x2_local, y2_local = map(float, box)
                        xc_local = (x1_local + x2_local) / 2.0
                        yc_local = (y1_local + y2_local) / 2.0
                        if args.edge_margin:
                            touches_internal_left = left > 0 and xc_local < args.edge_margin
                            touches_internal_top = top > 0 and yc_local < args.edge_margin
                            touches_internal_right = (
                                left + args.tile_size < dataset.width
                                and xc_local > args.tile_size - args.edge_margin
                            )
                            touches_internal_bottom = (
                                top + args.tile_size < dataset.height
                                and yc_local > args.tile_size - args.edge_margin
                            )
                            if any(
                                (
                                    touches_internal_left,
                                    touches_internal_top,
                                    touches_internal_right,
                                    touches_internal_bottom,
                                )
                            ):
                                continue
                        x1 = max(0.0, min(dataset.width, x1_local + left))
                        y1 = max(0.0, min(dataset.height, y1_local + top))
                        x2 = max(0.0, min(dataset.width, x2_local + left))
                        y2 = max(0.0, min(dataset.height, y2_local + top))
                        rows.append(
                            {
                                "raster": str(path.resolve()),
                                "scene": scene,
                                "window_id": window_id,
                                "window_col": left,
                                "window_row": top,
                                "class_id": int(class_id),
                                "confidence": float(score),
                                "x1_px": x1,
                                "y1_px": y1,
                                "x2_px": x2,
                                "y2_px": y2,
                                "x_center_px": (x1 + x2) / 2.0,
                                "y_center_px": (y1 + y2) / 2.0,
                                "width_px": max(x2 - x1, 0.0),
                                "height_px": max(y2 - y1, 0.0),
                            }
                        )
                current = window_id + 1
                if current == 1 or current % 100 == 0 or current == total_windows:
                    print(
                        f"[{scene} | {path.name}] {current}/{total_windows} windows | raw detections={len(rows)}",
                        flush=True,
                    )
        add_coordinates(rows, dataset)
        summary = {
            "scene": scene,
            "raster": str(path.resolve()),
            "width": dataset.width,
            "height": dataset.height,
            "bands": dataset.count,
            "bands_read_by_model": expected_channels,
            "offshore_extra_bands_ignored": (
                ["B8", "B12"] if scene == "offshore" and dataset.count == 5 else []
            ),
            "dtype": list(dataset.dtypes),
            "crs": dataset.crs.to_string() if dataset.crs else None,
            "total_windows": total_windows,
            "processed_windows": processed_windows,
            "empty_windows": empty_windows,
            "raw_detections": len(rows),
            "elapsed_seconds": round(time.perf_counter() - start, 3),
        }
    return rows, summary


def process_scene(model: YOLO, scene: str, source: Path, args: argparse.Namespace) -> dict:
    rasters = collect_rasters(source)
    all_raw: list[dict] = []
    all_deduplicated: list[dict] = []
    summaries = []
    errors = []
    for raster_path in rasters:
        try:
            raw, summary = process_raster(model, raster_path, scene, args)
            deduplicated = global_nms(raw, args.global_iou)
            summary["detections_after_within_raster_global_nms"] = len(deduplicated)
            summaries.append(summary)
            all_raw.extend(raw)
            all_deduplicated.extend(deduplicated)
            print(
                f"[{scene} | {raster_path.name}] raw={len(raw)}, "
                f"after global NMS={len(deduplicated)}",
                flush=True,
            )
        except Exception as exc:
            errors.append(
                {"scene": scene, "raster": str(raster_path.resolve()), "error": repr(exc)}
            )
            if not args.continue_on_error:
                raise RuntimeError(f"Failed on {scene} raster: {raster_path}") from exc

    # NMS above is performed separately per raster. If adjacent rasters overlap,
    # their seam duplicates must be removed later in projected map coordinates.
    raw_csv = args.output_dir / f"{scene}_raw_window_detections.csv"
    dedup_csv = args.output_dir / f"{scene}_within_raster_nms_detections.csv"
    geojson_path = args.output_dir / f"{scene}_within_raster_nms_points.geojson"
    error_csv = args.output_dir / f"{scene}_errors.csv"
    write_csv(raw_csv, all_raw)
    write_csv(dedup_csv, all_deduplicated)
    write_geojson(geojson_path, all_deduplicated, scene)
    with error_csv.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=["scene", "raster", "error"])
        writer.writeheader()
        writer.writerows(errors)

    return {
        "scene": scene,
        "source": str(source.resolve()),
        "band_order": BAND_ORDERS[scene],
        "confidence_threshold": args.land_conf if scene == "land" else args.offshore_conf,
        "raster_count": len(rasters),
        "raw_detection_count": len(all_raw),
        "within_raster_nms_detection_count": len(all_deduplicated),
        "error_count": len(errors),
        "outputs": {
            "raw_csv": str(raw_csv.resolve()),
            "within_raster_nms_csv": str(dedup_csv.resolve()),
            "within_raster_nms_geojson": str(geojson_path.resolve()),
            "errors_csv": str(error_csv.resolve()),
        },
        "rasters": summaries,
    }


def main() -> None:
    args = parse_args()
    validate_args(args)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Loading final UniWT-YOLO checkpoint: {args.weights.resolve()}")
    model = YOLO(str(args.weights.resolve()))

    scene_results = []
    if args.land_source is not None:
        scene_results.append(process_scene(model, "land", args.land_source, args))
    if args.offshore_source is not None:
        scene_results.append(process_scene(model, "offshore", args.offshore_source, args))
    selected_scenes = [result["scene"] for result in scene_results]

    manifest = {
        "experiment": "E4_scene_specific_shallow_DSBN_shared_head",
        "scenes": selected_scenes,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "weights": str(args.weights.resolve()),
        "weights_sha256": sha256(args.weights),
        "land_source": str(args.land_source.resolve()) if args.land_source is not None else None,
        "offshore_source": (
            str(args.offshore_source.resolve()) if args.offshore_source is not None else None
        ),
        "band_orders": BAND_ORDERS,
        "offshore_source_policy": (
            "Accept 3-band [B4,B3,B2] or 5-band [B4,B3,B2,B8,B12]; "
            "read bands 1-3 only for the offshore model route"
        ),
        "model_input": "uint8 [0,255] produced with the fixed training stretch",
        "input_mode": args.input_mode,
        "raw_stretch": {
            "land_optical_clip_max": LAND_OPTICAL_CLIP_MAX[:, 0, 0].tolist(),
            "land_sar_min": LAND_SAR_MIN[:, 0, 0].tolist(),
            "land_sar_max": LAND_SAR_MAX[:, 0, 0].tolist(),
            "offshore_optical_clip_max": OFFSHORE_OPTICAL_CLIP_MAX[:, 0, 0].tolist(),
        },
        "tile_size": args.tile_size,
        "stride": args.stride,
        "overlap": args.tile_size - args.stride,
        "confidence_thresholds": {
            "land": args.land_conf,
            "offshore": args.offshore_conf,
        },
        "within_window_nms_iou": args.tile_iou,
        "within_raster_global_nms_iou": args.global_iou,
        "edge_margin": args.edge_margin,
        "max_det_per_window": args.max_det,
        "device": args.device,
        "cross_raster_seam_deduplication_applied": False,
        "cluster_rule_applied": False,
        "manual_review_applied": False,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "ultralytics": ultralytics_version,
        "results": scene_results,
    }
    if selected_scenes == ["land"]:
        manifest_name = "land_inference_manifest.json"
    elif selected_scenes == ["offshore"]:
        manifest_name = "offshore_inference_manifest.json"
    else:
        manifest_name = "inference_manifest.json"
    manifest_path = args.output_dir / manifest_name
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"Finished: {manifest_path.resolve()}")


if __name__ == "__main__":
    main()
