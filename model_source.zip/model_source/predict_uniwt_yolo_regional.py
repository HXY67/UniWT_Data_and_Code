"""Nationwide inference with the final UniWT-YOLO checkpoint.

Run land (7-band) and offshore (RGB) TIFF tiles separately through one UniWT-YOLO
checkpoint. The script writes one CSV per scene, YOLO-format TXT labels, an
error log, and a JSON provenance manifest suitable for archiving with a paper.

Land band order must be: B4, B3, B2, B8, B12, VV, VH.
Offshore band order must be: B4, B3, B2 (RGB).
Both domains use 256 x 256 px inference by default.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np
import torch


ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# This registration MUST happen before importing/loading YOLO. It restores the
# custom UniWT-YOLO Stem and DSBN classes used by best.pt.
from unified_wt.modules import register_unified_components  # noqa: E402

register_unified_components()

from ultralytics import YOLO, __version__ as ultralytics_version  # noqa: E402
from ultralytics.utils.patches import imread  # noqa: E402


TIFF_SUFFIXES = {".tif", ".tiff"}
CSV_FIELDS = [
    "tile",
    "scene",
    "class_id",
    "confidence",
    "x1_px",
    "y1_px",
    "x2_px",
    "y2_px",
    "x_center_px",
    "y_center_px",
    "width_px",
    "height_px",
    "x_center_norm",
    "y_center_norm",
    "width_norm",
    "height_norm",
    "x_map",
    "y_map",
    "longitude",
    "latitude",
    "source_crs",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Final UniWT-YOLO nationwide land/offshore wind-turbine inference"
    )
    parser.add_argument("--weights", type=Path, required=True, help="Final UniWT-YOLO best.pt")
    parser.add_argument("--land-source", type=Path, default=None, help="Land TIFF tile or directory")
    parser.add_argument("--offshore-source", type=Path, default=None, help="Offshore TIFF tile or directory")
    parser.add_argument("--output-dir", type=Path, required=True, help="Output directory")
    parser.add_argument("--imgsz", type=int, default=256)
    parser.add_argument("--land-conf", type=float, default=0.25)
    parser.add_argument("--offshore-conf", type=float, default=0.25)
    parser.add_argument("--iou", type=float, default=0.70, help="Within-tile NMS IoU")
    parser.add_argument("--max-det", type=int, default=300)
    parser.add_argument("--device", default="0", help="CUDA device such as 0, or cpu")
    parser.add_argument(
        "--allow-non-256",
        action="store_true",
        help="Allow source tiles whose native size is not 256 x 256",
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Log unreadable tiles and continue instead of stopping",
    )
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if not args.weights.is_file():
        raise FileNotFoundError(f"Weights not found: {args.weights}")
    if args.land_source is None and args.offshore_source is None:
        raise ValueError("Supply --land-source and/or --offshore-source.")
    for name in ("land_source", "offshore_source"):
        source = getattr(args, name)
        if source is not None and not source.exists():
            raise FileNotFoundError(f"{name} not found: {source}")
    if args.imgsz <= 0 or args.imgsz % 32:
        raise ValueError(f"--imgsz must be a positive multiple of 32, got {args.imgsz}")
    for name in ("land_conf", "offshore_conf", "iou"):
        value = float(getattr(args, name))
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"--{name.replace('_', '-')} must be in [0, 1], got {value}")


def collect_tiffs(source: Path) -> list[Path]:
    if source.is_file():
        if source.suffix.lower() not in TIFF_SUFFIXES:
            raise ValueError(f"Not a TIFF: {source}")
        return [source]
    files = sorted(p for p in source.rglob("*") if p.is_file() and p.suffix.lower() in TIFF_SUFFIXES)
    if not files:
        raise FileNotFoundError(f"No .tif/.tiff files found under: {source}")
    return files


def sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_uint8_tiff(path: Path, scene: str) -> np.ndarray:
    expected_channels = 7 if scene == "land" else 3
    image = imread(str(path))
    if image is None:
        raise ValueError("image reader returned None")
    if image.ndim == 2:
        image = image[..., None]
    if image.ndim != 3 or image.shape[2] != expected_channels:
        raise ValueError(
            f"shape={image.shape}; expected HWC with {expected_channels} channels for {scene}"
        )
    if not np.isfinite(image).all():
        raise ValueError("contains NaN or Inf")
    minimum, maximum = float(image.min()), float(image.max())
    if minimum < 0 or maximum > 255:
        raise ValueError(
            f"range=[{minimum}, {maximum}], but UniWT-YOLO expects the same uint8 0-255 stretch used for training"
        )
    image = image.astype(np.uint8, copy=False)

    # Ultralytics/OpenCV reads a conventional 3-channel RGB TIFF as BGR. The
    # offshore model was trained after BGR->RGB conversion. Seven-band land
    # TIFF pages must retain their stored order and therefore are not reversed.
    if scene == "offshore":
        image = image[..., ::-1]
    return np.ascontiguousarray(image)


def letterbox(image: np.ndarray, imgsz: int) -> tuple[torch.Tensor, float, int, int]:
    height, width = image.shape[:2]
    ratio = min(imgsz / height, imgsz / width)
    new_width = int(round(width * ratio))
    new_height = int(round(height * ratio))
    if (new_width, new_height) != (width, height):
        image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_LINEAR)
        if image.ndim == 2:
            image = image[..., None]
    left = int(round((imgsz - new_width) / 2.0 - 0.1))
    top = int(round((imgsz - new_height) / 2.0 - 0.1))
    canvas = np.full((imgsz, imgsz, image.shape[2]), 114, dtype=np.uint8)
    canvas[top : top + new_height, left : left + new_width] = image
    tensor = torch.from_numpy(canvas.transpose(2, 0, 1).copy()).float().unsqueeze(0) / 255.0
    return tensor, ratio, left, top


def restore_boxes(
    boxes: np.ndarray,
    ratio: float,
    left: int,
    top: int,
    width: int,
    height: int,
) -> np.ndarray:
    if boxes.size == 0:
        return boxes
    boxes[:, [0, 2]] = (boxes[:, [0, 2]] - left) / ratio
    boxes[:, [1, 3]] = (boxes[:, [1, 3]] - top) / ratio
    boxes[:, [0, 2]] = boxes[:, [0, 2]].clip(0, width)
    boxes[:, [1, 3]] = boxes[:, [1, 3]].clip(0, height)
    return boxes


def geospatial_centres(path: Path, pixel_centres: list[tuple[float, float]]) -> dict:
    """Return map and WGS84 centres when the TIFF has valid georeferencing."""
    empty = {
        "map": [(None, None)] * len(pixel_centres),
        "wgs84": [(None, None)] * len(pixel_centres),
        "crs": "",
    }
    try:
        import rasterio
        from rasterio.crs import CRS
        from rasterio.transform import xy
        from rasterio.warp import transform

        with rasterio.open(path) as dataset:
            if dataset.crs is None:
                return empty
            map_points = [xy(dataset.transform, py, px, offset="center") for px, py in pixel_centres]
            xs = [point[0] for point in map_points]
            ys = [point[1] for point in map_points]
            if dataset.crs == CRS.from_epsg(4326):
                lons, lats = xs, ys
            else:
                lons, lats = transform(dataset.crs, "EPSG:4326", xs, ys)
            return {
                "map": list(zip(xs, ys)),
                "wgs84": list(zip(lons, lats)),
                "crs": dataset.crs.to_string(),
            }
    except Exception:
        # Georeferencing is optional; pixel detections remain valid.
        return empty


def label_path_for(tile: Path, source: Path, label_root: Path) -> Path:
    if source.is_file():
        relative = Path(tile.name)
    else:
        relative = tile.relative_to(source)
    return (label_root / relative).with_suffix(".txt")


def predict_scene(
    model: YOLO,
    scene: str,
    source: Path,
    output_dir: Path,
    imgsz: int,
    conf: float,
    iou: float,
    max_det: int,
    device: str,
    allow_non_256: bool,
    continue_on_error: bool,
) -> dict:
    files = collect_tiffs(source)
    csv_path = output_dir / f"{scene}_detections.csv"
    labels_root = output_dir / f"{scene}_labels"
    labels_root.mkdir(parents=True, exist_ok=True)
    error_path = output_dir / f"{scene}_errors.csv"
    errors: list[dict[str, str]] = []
    detection_count = 0
    tiles_with_detections = 0
    started = time.perf_counter()

    with csv_path.open("w", newline="", encoding="utf-8-sig") as csv_stream:
        writer = csv.DictWriter(csv_stream, fieldnames=CSV_FIELDS)
        writer.writeheader()

        for index, path in enumerate(files, start=1):
            try:
                image = load_uint8_tiff(path, scene)
                height, width = image.shape[:2]
                if not allow_non_256 and (height, width) != (256, 256):
                    raise ValueError(
                        f"native size is {width}x{height}; expected 256x256. "
                        "Use --allow-non-256 only if this is intentional."
                    )
                tensor, ratio, left, top = letterbox(image, imgsz)
                result = model.predict(
                    source=tensor,
                    conf=conf,
                    iou=iou,
                    max_det=max_det,
                    device=device,
                    verbose=False,
                )[0]

                label_path = label_path_for(path, source, labels_root)
                label_path.parent.mkdir(parents=True, exist_ok=True)
                label_lines: list[str] = []
                if result.boxes is not None and len(result.boxes):
                    boxes = restore_boxes(
                        result.boxes.xyxy.detach().cpu().numpy().copy(),
                        ratio,
                        left,
                        top,
                        width,
                        height,
                    )
                    confidences = result.boxes.conf.detach().cpu().numpy()
                    classes = result.boxes.cls.detach().cpu().numpy().astype(int)
                    centres = [((b[0] + b[2]) / 2.0, (b[1] + b[3]) / 2.0) for b in boxes]
                    geo = geospatial_centres(path, centres)
                    tiles_with_detections += 1

                    for box, score, class_id, centre, map_xy, lon_lat in zip(
                        boxes, confidences, classes, centres, geo["map"], geo["wgs84"]
                    ):
                        x1, y1, x2, y2 = map(float, box)
                        xc, yc = map(float, centre)
                        bw, bh = max(x2 - x1, 0.0), max(y2 - y1, 0.0)
                        row = {
                            "tile": str(path.resolve()),
                            "scene": scene,
                            "class_id": int(class_id),
                            "confidence": float(score),
                            "x1_px": x1,
                            "y1_px": y1,
                            "x2_px": x2,
                            "y2_px": y2,
                            "x_center_px": xc,
                            "y_center_px": yc,
                            "width_px": bw,
                            "height_px": bh,
                            "x_center_norm": xc / width,
                            "y_center_norm": yc / height,
                            "width_norm": bw / width,
                            "height_norm": bh / height,
                            "x_map": map_xy[0],
                            "y_map": map_xy[1],
                            "longitude": lon_lat[0],
                            "latitude": lon_lat[1],
                            "source_crs": geo["crs"],
                        }
                        writer.writerow(row)
                        label_lines.append(
                            f"{class_id} {xc / width:.8f} {yc / height:.8f} "
                            f"{bw / width:.8f} {bh / height:.8f} {float(score):.8f}"
                        )
                        detection_count += 1
                label_path.write_text("\n".join(label_lines), encoding="utf-8")

                if index == 1 or index % 100 == 0 or index == len(files):
                    print(
                        f"[{scene}] {index}/{len(files)} tiles | "
                        f"current detections={detection_count}",
                        flush=True,
                    )
            except Exception as exc:
                errors.append({"tile": str(path.resolve()), "error": repr(exc)})
                if not continue_on_error:
                    raise RuntimeError(f"Failed on {scene} tile: {path}") from exc

    with error_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=["tile", "error"])
        writer.writeheader()
        writer.writerows(errors)

    return {
        "scene": scene,
        "source": str(source.resolve()),
        "tile_count": len(files),
        "tiles_with_detections": tiles_with_detections,
        "detection_count_before_cross_tile_deduplication": detection_count,
        "error_count": len(errors),
        "confidence_threshold": conf,
        "csv": str(csv_path.resolve()),
        "labels": str(labels_root.resolve()),
        "errors": str(error_path.resolve()),
        "elapsed_seconds": round(time.perf_counter() - started, 3),
    }


def main() -> None:
    args = parse_args()
    validate_args(args)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Loading final UniWT-YOLO checkpoint: {args.weights.resolve()}")
    model = YOLO(str(args.weights.resolve()))
    summaries = []

    if args.land_source is not None:
        summaries.append(
            predict_scene(
                model=model,
                scene="land",
                source=args.land_source,
                output_dir=args.output_dir,
                imgsz=args.imgsz,
                conf=args.land_conf,
                iou=args.iou,
                max_det=args.max_det,
                device=args.device,
                allow_non_256=args.allow_non_256,
                continue_on_error=args.continue_on_error,
            )
        )
    if args.offshore_source is not None:
        summaries.append(
            predict_scene(
                model=model,
                scene="offshore",
                source=args.offshore_source,
                output_dir=args.output_dir,
                imgsz=args.imgsz,
                conf=args.offshore_conf,
                iou=args.iou,
                max_det=args.max_det,
                device=args.device,
                allow_non_256=args.allow_non_256,
                continue_on_error=args.continue_on_error,
            )
        )

    manifest = {
        "experiment": "E4_scene_specific_shallow_DSBN_shared_head",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "weights": str(args.weights.resolve()),
        "weights_sha256": sha256(args.weights),
        "land_band_order": ["B4", "B3", "B2", "B8", "B12", "VV", "VH"],
        "offshore_band_order": ["B4", "B3", "B2"],
        "imgsz": args.imgsz,
        "nms_iou": args.iou,
        "max_det": args.max_det,
        "device": args.device,
        "cross_tile_deduplication_applied": False,
        "manual_review_applied": False,
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "ultralytics": ultralytics_version,
        "scenes": summaries,
    }
    manifest_path = args.output_dir / "inference_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(f"Finished. Manifest: {manifest_path.resolve()}")


if __name__ == "__main__":
    main()
