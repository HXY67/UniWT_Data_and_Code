"""Run Experiment 4 under the same protocol as Experiment 3."""

from __future__ import annotations

import os
os.environ["OPENCV_LOG_LEVEL"] = "SILENT"

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from unified_wt.scene_shallow_dsbn_shared import SceneShallowDSBNSharedTrainer


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=ROOT / "configs/uniwt_yolo_architecture.yaml")
    parser.add_argument("--land-data", type=Path, default=ROOT / "configs/data_land.yaml")
    parser.add_argument("--offshore-data", type=Path, default=ROOT / "configs/data_offshore.yaml")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--device", default="0")
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--seed", type=int, default=2)
    parser.add_argument("--project", type=Path, default=ROOT / "runs/uniwt_yolo")
    parser.add_argument("--name", default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    for path in (args.model, args.land_data, args.offshore_data):
        if not path.is_file():
            raise FileNotFoundError(path)
    for path in (args.land_data, args.offshore_data):
        if "YOUR_DATA" in path.read_text(encoding="utf-8"):
            raise RuntimeError(f"Dataset path is not configured: {path}")

    overrides = {
        "model": str(args.model.resolve()), "epochs": args.epochs, "batch": args.batch, "imgsz": 256,
        "device": args.device, "workers": args.workers, "project": str(args.project.resolve()),
        "name": args.name or f"E4_seed{args.seed}", "task": "detect", "pretrained": False,
        "optimizer": "SGD", "lr0": 0.005, "lrf": 0.01, "momentum": 0.937,
        "weight_decay": 0.0005, "warmup_epochs": 3.0, "warmup_momentum": 0.8,
        "warmup_bias_lr": 0.1, "amp": False, "seed": args.seed, "deterministic": True, "nbs": 64,
        "patience": 15, "save_period": -1, "mosaic": 0.0, "mixup": 0.0, "cutmix": 0.0,
        "close_mosaic": 0, "degrees": 0.0, "translate": 0.0, "scale": 0.0,
        "shear": 0.0, "perspective": 0.0, "fliplr": 0.5, "flipud": 0.5,
        "hsv_h": 0.0, "hsv_s": 0.0, "hsv_v": 0.0, "bgr": 0.0, "multi_scale": 0.0,
        "iou": 0.7, "cache": False, "rect": False, "val": True, "plots": True,
        "save": True, "exist_ok": False,
    }
    print("UniWT-YOLO: scene-specific Stem/P2 | DSBN | shared standard Detect")
    trainer = SceneShallowDSBNSharedTrainer(
        land_data=args.land_data, offshore_data=args.offshore_data,
        land_imgsz=256, offshore_imgsz=256, save_first_n_epochs=20, overrides=overrides,
    )
    trainer.train()


if __name__ == "__main__":
    main()
