"""V4 utilities for unified land/offshore wind-turbine detection."""

from .modules import (
    SceneSpecificBatchNorm2d,
    SceneSpecificDetect,
    SceneSpecificShallowStem,
    register_unified_components,
)

__all__ = (
    "SceneSpecificBatchNorm2d",
    "SceneSpecificDetect",
    "SceneSpecificShallowStem",
    "UnifiedWindTurbineTrainer",
    "register_unified_components",
)


def __getattr__(name):
    """Load the trainer lazily so checkpoint unpickling avoids import cycles."""
    if name == "UnifiedWindTurbineTrainer":
        from .trainer import UnifiedWindTurbineTrainer

        return UnifiedWindTurbineTrainer
    raise AttributeError(name)
