"""Non-repeating two-domain dataloader helpers for the V4 trainer.

Three-channel offshore samples and seven-channel land samples cannot be stacked
in the same tensor. ``InterleavedDomainLoader`` keeps each batch homogeneous,
spreads the smaller loader evenly across the epoch, and consumes every
underlying batch exactly once. No domain is silently cycled or oversampled.
"""

from __future__ import annotations

from typing import Iterator

import torch


class _CombinedDatasetProxy:
    """Expose the dataset attributes used by the stock Ultralytics trainer."""

    def __init__(self, land_dataset, offshore_dataset):
        self.land_dataset = land_dataset
        self.offshore_dataset = offshore_dataset
        self.labels = list(land_dataset.labels) + list(offshore_dataset.labels)

    def __len__(self) -> int:
        return len(self.land_dataset) + len(self.offshore_dataset)

    @property
    def mosaic(self) -> bool:
        return bool(getattr(self.land_dataset, "mosaic", False) or getattr(self.offshore_dataset, "mosaic", False))

    @mosaic.setter
    def mosaic(self, value: bool) -> None:
        for dataset in (self.land_dataset, self.offshore_dataset):
            if hasattr(dataset, "mosaic"):
                dataset.mosaic = value

    def close_mosaic(self, hyp) -> None:
        for dataset in (self.land_dataset, self.offshore_dataset):
            if hasattr(dataset, "close_mosaic"):
                dataset.close_mosaic(hyp=hyp)


class _SamplerProxy:
    """Forward epoch updates to both underlying samplers."""

    def __init__(self, land_sampler, offshore_sampler):
        self.land_sampler = land_sampler
        self.offshore_sampler = offshore_sampler

    def set_epoch(self, epoch: int) -> None:
        for sampler in (self.land_sampler, self.offshore_sampler):
            if hasattr(sampler, "set_epoch"):
                sampler.set_epoch(epoch)


class InterleavedDomainLoader:
    """Interleave both loaders without repeating either one.

    The next domain is selected from normalized progress. Equal-sized loaders
    alternate exactly; unequal loaders place the smaller domain's batches at
    approximately uniform intervals throughout the epoch instead of appending
    a long single-domain tail.
    """

    def __init__(self, land_loader, offshore_loader):
        self.land_loader = land_loader
        self.offshore_loader = offshore_loader
        self.land_batches = len(land_loader)
        self.offshore_batches = len(offshore_loader)
        if self.land_batches == 0 or self.offshore_batches == 0:
            raise ValueError("Both land and offshore training loaders must contain at least one batch.")

        self.dataset = _CombinedDatasetProxy(land_loader.dataset, offshore_loader.dataset)
        self.num_workers = int(getattr(land_loader, "num_workers", 0)) + int(
            getattr(offshore_loader, "num_workers", 0)
        )
        self.batch_size = getattr(land_loader, "batch_size", None)
        self.sampler = _SamplerProxy(getattr(land_loader, "sampler", None), getattr(offshore_loader, "sampler", None))

    def __len__(self) -> int:
        return self.land_batches + self.offshore_batches

    @staticmethod
    def _validate_channels(batch: dict, expected: int, scene: str) -> None:
        image = batch.get("img")
        if not isinstance(image, torch.Tensor) or image.ndim != 4:
            raise TypeError(f"{scene} batch must contain a BCHW torch.Tensor under batch['img'].")
        actual = int(image.shape[1])
        if actual != expected:
            files = batch.get("im_file", ())
            example = files[0] if files else "unknown file"
            raise ValueError(
                f"{scene} batch must have {expected} channels but has {actual}. "
                f"Check TIFF band order and data YAML. Example: {example}"
            )

    @classmethod
    def _tag(cls, batch: dict, scene: str, expected_channels: int) -> dict:
        cls._validate_channels(batch, expected=expected_channels, scene=scene)
        batch["scene"] = scene
        return batch

    def __iter__(self) -> Iterator[dict]:
        land_iterator = iter(self.land_loader)
        offshore_iterator = iter(self.offshore_loader)
        land_used = 0
        offshore_used = 0

        while land_used < self.land_batches or offshore_used < self.offshore_batches:
            land_progress = land_used / self.land_batches
            offshore_progress = offshore_used / self.offshore_batches
            choose_land = land_used < self.land_batches and (
                offshore_used >= self.offshore_batches or land_progress <= offshore_progress
            )

            if choose_land:
                land_used += 1
                yield self._tag(next(land_iterator), scene="land", expected_channels=7)
            else:
                offshore_used += 1
                yield self._tag(next(offshore_iterator), scene="offshore", expected_channels=3)

        if land_used != self.land_batches or offshore_used != self.offshore_batches:
            raise RuntimeError("Domain loader consumption mismatch.")

    def reset(self) -> None:
        """Reset both persistent Ultralytics dataloader iterators."""
        for loader in (self.land_loader, self.offshore_loader):
            if hasattr(loader, "reset"):
                loader.reset()


# Backward-compatible import name for scripts written against v1.
BalancedDomainLoader = InterleavedDomainLoader
