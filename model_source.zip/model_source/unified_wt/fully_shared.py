"""Experiment 2 fully shared trainer with zero-padded offshore inputs."""

from __future__ import annotations

from copy import copy

import torch

from ultralytics.models.yolo.detect.val import DetectionValidator
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import LOGGER, YAML

from .modules import set_active_scene
from .trainer import UnifiedWindTurbineTrainer


def pad_offshore_to_seven(batch: dict) -> dict:
    """Map offshore [B4,B3,B2] to [B4,B3,B2,0,0,0,0]."""
    image = batch["img"]
    if image.ndim != 4:
        raise ValueError(f"Expected BCHW image tensor, got {tuple(image.shape)}")
    channels = int(image.shape[1])
    if channels == 7:
        return batch
    if channels != 3:
        raise ValueError(f"Fully shared model accepts raw 3ch offshore or 7ch land, got {channels}ch")
    zeros = torch.zeros(
        image.shape[0], 4, image.shape[2], image.shape[3],
        dtype=image.dtype, device=image.device,
    )
    batch["img"] = torch.cat((image, zeros), dim=1)
    return batch


class OffshorePaddedValidator(DetectionValidator):
    """Standard validator that pads offshore RGB immediately before inference."""

    def preprocess(self, batch: dict) -> dict:
        batch = super().preprocess(batch)
        return pad_offshore_to_seven(batch)


class FullySharedTrainer(UnifiedWindTurbineTrainer):
    """One input convolution, ordinary BN and one Detect head for both domains."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        YAML.save(
            self.save_dir / "E4_seed1_experiment_identity.yaml",
            {
                "experiment": "E2_fully_shared",
                "land_input": ["B4", "B3", "B2", "B8", "B12", "VV", "VH"],
                "offshore_input": ["B4", "B3", "B2", 0, 0, 0, 0],
                "stem": "shared",
                "batch_norm": "shared ordinary BN",
                "backbone_neck": "shared",
                "detect_head": "shared standard YOLOv8 Detect",
                "SG": False,
                "PCAS": False,
                "DSBN": False,
            },
        )

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=7, verbose=verbose)
        if weights:
            model.load(weights)
        LOGGER.info("E2 fully shared graph: shared 7ch input, ordinary BN, shared Detect head.")
        return model

    def preprocess_batch(self, batch: dict) -> dict:
        scene = batch.get("scene")
        if scene not in {"land", "offshore"}:
            raise ValueError(f"Missing valid scene tag: {scene!r}")
        expected_size = self.land_imgsz if scene == "land" else self.offshore_imgsz
        if tuple(batch["img"].shape[-2:]) != (expected_size, expected_size):
            raise ValueError(f"Unexpected {scene} spatial shape: {tuple(batch['img'].shape[-2:])}")
        self._current_scene = scene
        set_active_scene(scene)
        batch["domain_loss_weight"] = self.domain_loss_weights[scene]
        if scene == "offshore":
            batch = pad_offshore_to_seven(batch)
        return super(UnifiedWindTurbineTrainer, self).preprocess_batch(batch)

    def get_validator(self):
        self.loss_names = "box_loss", "cls_loss", "dfl_loss"
        land_args = copy(self.args)
        land_args.data = self.land_data_file
        land_args.imgsz = self.land_imgsz
        offshore_args = copy(self.args)
        offshore_args.data = self.offshore_data_file
        offshore_args.imgsz = self.offshore_imgsz
        self.land_validator = DetectionValidator(
            self.land_test_loader, save_dir=self.save_dir / "val_land",
            args=land_args, _callbacks=self.callbacks,
        )
        self.offshore_validator = OffshorePaddedValidator(
            self.offshore_test_loader, save_dir=self.save_dir / "val_offshore",
            args=offshore_args, _callbacks=self.callbacks,
        )
        return self.land_validator
