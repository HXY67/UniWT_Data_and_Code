"""V4 scene-conditioned modules for unified land/offshore turbine detection.

Architecture policy:
* Separate Stem + P2 paths for 7-channel land and 3-channel offshore inputs.
* Shared P3-P5 backbone and PAN/FPN neck convolution weights.
* Domain-specific BatchNorm (DSBN) in the shared path.
* Separate YOLOv8 detection heads; PCAS is enabled only for land.

Ultralytics 8.4.38 resolves YAML symbols through ``ultralytics.nn.tasks``.
Registration reuses the existing SARGatedStem and PCADetect parser slots so
the vendored package does not require another invasive source-code patch.
"""

from __future__ import annotations

from contextvars import ContextVar
from copy import deepcopy

import torch
import torch.nn as nn

from ultralytics.nn.modules.block import C2f
from ultralytics.nn.modules.conv import Conv
from ultralytics.nn.modules.head import Detect, PCADetect as _OriginalPCADetect
from ultralytics.utils.loss import v8DetectionLoss, v8PCADetectionLoss


_ACTIVE_SCENE: ContextVar[str | None] = ContextVar("unified_wt_active_scene", default=None)
VALID_SCENES = frozenset({"land", "offshore"})


def set_active_scene(scene: str) -> None:
    """Select the route used by DSBN and the scene-specific detection head."""
    if scene not in VALID_SCENES:
        raise ValueError(f"scene must be one of {sorted(VALID_SCENES)}, got {scene!r}")
    _ACTIVE_SCENE.set(scene)


def get_active_scene() -> str:
    """Return the active homogeneous-batch scene, failing loudly if unset."""
    scene = _ACTIVE_SCENE.get()
    if scene not in VALID_SCENES:
        raise RuntimeError(
            "Scene route is unset. Send a 7-channel land or 3-channel offshore "
            "batch through SceneSpecificShallowStem first."
        )
    return scene


class SceneSpecificBatchNorm2d(nn.Module):
    """Two BN states selected by scene while the surrounding convolution is shared."""

    def __init__(
        self,
        num_features: int,
        eps: float = 1e-5,
        momentum: float | None = 0.1,
        affine: bool = True,
        track_running_stats: bool = True,
    ):
        super().__init__()
        kwargs = dict(
            num_features=num_features,
            eps=eps,
            momentum=momentum,
            affine=affine,
            track_running_stats=track_running_stats,
        )
        self.land = nn.BatchNorm2d(**kwargs)
        self.offshore = nn.BatchNorm2d(**kwargs)

    @classmethod
    def from_batch_norm(cls, source: nn.BatchNorm2d) -> "SceneSpecificBatchNorm2d":
        """Clone one initialized BN into independent land and offshore states."""
        target = cls(
            source.num_features,
            eps=source.eps,
            momentum=source.momentum,
            affine=source.affine,
            track_running_stats=source.track_running_stats,
        )
        target.land.load_state_dict(deepcopy(source.state_dict()))
        target.offshore.load_state_dict(deepcopy(source.state_dict()))
        return target

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.land(x) if get_active_scene() == "land" else self.offshore(x)

    def extra_repr(self) -> str:
        return f"num_features={self.land.num_features}, routes=land|offshore"


def _replace_bn_recursively(module: nn.Module) -> int:
    replaced = 0
    for name, child in list(module.named_children()):
        if isinstance(child, SceneSpecificBatchNorm2d):
            continue
        if isinstance(child, nn.BatchNorm2d):
            setattr(module, name, SceneSpecificBatchNorm2d.from_batch_norm(child))
            replaced += 1
        else:
            replaced += _replace_bn_recursively(child)
    return replaced


def install_shared_dsbn(model: nn.Module, first_shared_index: int = 1, head_index: int = -1) -> int:
    """Replace BN only in shared backbone/neck, excluding private Stem and heads."""
    graph = getattr(model, "model", None)
    if not isinstance(graph, nn.Sequential):
        raise TypeError("Expected an Ultralytics model with nn.Sequential at model.model")
    stop = len(graph) + head_index if head_index < 0 else head_index
    if first_shared_index < 0 or stop <= first_shared_index:
        raise ValueError(f"Invalid shared DSBN range [{first_shared_index}, {stop})")
    count = 0
    for layer in list(graph.children())[first_shared_index:stop]:
        count += _replace_bn_recursively(layer)
    model._uses_scene_specific_bn = True
    model._scene_specific_bn_count = count
    return count


class SceneSpecificShallowStem(nn.Module):
    """Separate input Stem and P2 extraction paths, merged before shared P3."""

    def __init__(self, c1: int, c2: int, k: int = 3, s: int = 2):
        super().__init__()
        if c1 != 7:
            raise ValueError(f"V4 graph must be parsed with ch=7, received c1={c1}.")
        c_mid = max(c2 // 2, 8)

        # Offshore RGB path: Sentinel-2 [B4, B3, B2].
        self.rgb_conv = Conv(3, c_mid, k, s)
        self.rgb_down = Conv(c_mid, c2, 3, 2)
        self.rgb_c2f = C2f(c2, c2, n=1, shortcut=True)

        # Land SG path: S2 main stream; S1 supplies weak spatial modulation.
        self.s2_conv = Conv(5, c_mid, k, s)
        self.sar_conv = nn.Sequential(Conv(2, c_mid, k, s), Conv(c_mid, c_mid, 3, 1))
        self.gate = nn.Sequential(nn.Conv2d(c_mid, c_mid, 1, 1, 0, bias=True), nn.Sigmoid())
        self.land_down = Conv(c_mid, c2, 3, 2)
        self.land_c2f = C2f(c2, c2, n=1, shortcut=True)
        self.alpha = nn.Parameter(torch.tensor(-2.0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 4:
            raise ValueError(f"V4 Stem expects BCHW input, got {tuple(x.shape)}")
        channels = int(x.shape[1])
        if channels == 3:
            set_active_scene("offshore")
            return self.rgb_c2f(self.rgb_down(self.rgb_conv(x)))
        if channels == 7:
            set_active_scene("land")
            f_s2 = self.s2_conv(x[:, :5])
            f_sar = self.sar_conv(x[:, 5:7])
            gate = self.gate(f_sar)
            alpha = torch.sigmoid(self.alpha) * 0.1
            fused = f_s2 * (1.0 + alpha * (gate - 0.5))
            return self.land_c2f(self.land_down(fused))
        raise ValueError(f"V4 supports only 3-channel offshore or 7-channel land batches, got {channels}.")


class SceneSpecificDetect(_OriginalPCADetect):
    """Inherited land PCAS head plus an independent offshore YOLOv8 head."""

    def __init__(
        self,
        nc: int = 80,
        heatmap_gain: float = 0.10,
        offset_gain: float = 0.05,
        gaussian_radius: int = 1,
        reg_max: int = 16,
        end2end: bool = False,
        ch: tuple = (),
    ):
        if end2end:
            raise ValueError("V4 supports the standard one-to-many YOLOv8 head only.")
        super().__init__(nc, heatmap_gain, offset_gain, gaussian_radius, reg_max, end2end, ch)
        # parse_model sets SceneSpecificDetect.legacy before construction. Build
        # the offshore head under the identical YOLOv8 compatibility policy.
        previous_legacy = Detect.legacy
        try:
            Detect.legacy = bool(self.legacy)
            self.offshore_head = Detect(nc=nc, reg_max=reg_max, end2end=False, ch=ch)
            self.offshore_head.legacy = bool(self.legacy)
        finally:
            Detect.legacy = previous_legacy
        self.head_policy = "land=PCADetect; offshore=Detect"

    def _sync_offshore_runtime(self, features: list[torch.Tensor] | None = None) -> None:
        self.offshore_head.stride = self.stride
        for name in ("dynamic", "export", "format", "max_det", "agnostic_nms", "xyxy"):
            if hasattr(self, name):
                setattr(self.offshore_head, name, getattr(self, name))
        # DetectionModel._apply moves the outer head's non-buffer decode cache,
        # but it cannot know about this nested private head. Invalidate a stale
        # CPU/GPU cache so Detect regenerates anchors on the current device.
        if features:
            device = features[0].device
            anchors = self.offshore_head.anchors
            strides = self.offshore_head.strides
            dtype = features[0].dtype
            if (
                anchors.device != device
                or strides.device != device
                or anchors.dtype != dtype
                or strides.dtype != dtype
            ):
                self.offshore_head.shape = None
                self.offshore_head.anchors = torch.empty(0, device=device, dtype=dtype)
                self.offshore_head.strides = torch.empty(0, device=device, dtype=dtype)

    def forward(self, x: list[torch.Tensor]):
        if get_active_scene() == "land":
            return super().forward(x)
        self._sync_offshore_runtime(x)
        return self.offshore_head(x)

    def bias_init(self) -> None:
        super().bias_init()
        self._sync_offshore_runtime()
        self.offshore_head.bias_init()


class SceneSpecificDetectionLoss:
    """Dispatch PCAS loss for land and standard detection loss for offshore."""

    def __init__(self, model):
        self.land_criterion = v8PCADetectionLoss(model)
        self.offshore_criterion = v8DetectionLoss(model)

    def __call__(self, preds, batch):
        scene = batch.get("scene") or get_active_scene()
        if scene == "land":
            return self.land_criterion(preds, batch)
        if scene == "offshore":
            return self.offshore_criterion(preds, batch)
        raise ValueError(f"Loss received invalid scene tag {scene!r}")


def _patch_band_order_handling() -> None:
    from ultralytics.data.dataset import YOLODataset

    current = YOLODataset.build_transforms
    if getattr(current, "_scg_preserve_band_order", False):
        return
    original = current

    def build_transforms(self, hyp=None):
        transforms = original(self, hyp)
        if self.data.get("preserve_channel_order", False):
            formatter = transforms[-1]
            if not hasattr(formatter, "bgr"):
                raise RuntimeError("Unable to locate Ultralytics Format transform.")
            formatter.bgr = 1.0
        return transforms

    build_transforms._scg_preserve_band_order = True
    build_transforms._scg_original = original
    YOLODataset.build_transforms = build_transforms


def _patch_domain_balanced_loss() -> None:
    from ultralytics.nn.tasks import BaseModel

    current = BaseModel.loss
    if getattr(current, "_scg_domain_balanced", False):
        return
    original = current

    def loss(self, batch, preds=None):
        total, items = original(self, batch, preds)
        return total * float(batch.get("domain_loss_weight", 1.0)), items

    loss._scg_domain_balanced = True
    loss._scg_original = original
    BaseModel.loss = loss


def _patch_scene_criterion_and_fuse() -> None:
    """Install loss dispatch and prevent invalid Conv+DSBN fusion."""
    from ultralytics.nn.tasks import BaseModel, DetectionModel

    current_init = DetectionModel.init_criterion
    if not getattr(current_init, "_scg_v4_scene_criterion", False):
        original_init = current_init

        def init_criterion(self):
            if isinstance(self.model[-1], SceneSpecificDetect):
                return SceneSpecificDetectionLoss(self)
            return original_init(self)

        init_criterion._scg_v4_scene_criterion = True
        init_criterion._scg_original = original_init
        DetectionModel.init_criterion = init_criterion

    current_fuse = BaseModel.fuse
    if not getattr(current_fuse, "_scg_v4_dsbn_safe", False):
        original_fuse = current_fuse

        def fuse(self, verbose=True):
            if getattr(self, "_uses_scene_specific_bn", False) or any(
                isinstance(m, SceneSpecificBatchNorm2d) for m in self.modules()
            ):
                return self
            return original_fuse(self, verbose=verbose)

        fuse._scg_v4_dsbn_safe = True
        fuse._scg_original = original_fuse
        BaseModel.fuse = fuse


def register_unified_components() -> None:
    """Register all V4 modules and compatibility patches once."""
    import ultralytics.nn.modules as nn_modules
    import ultralytics.nn.tasks as tasks

    tasks.SARGatedStem = SceneSpecificShallowStem
    nn_modules.SARGatedStem = SceneSpecificShallowStem
    tasks.PCADetect = SceneSpecificDetect
    nn_modules.PCADetect = SceneSpecificDetect
    _patch_band_order_handling()
    _patch_domain_balanced_loss()
    _patch_scene_criterion_and_fuse()
