"""Experiment 4: scene-specific shallow paths, DSBN, one shared Detect head."""

from __future__ import annotations

from ultralytics.nn.modules.head import Detect
from ultralytics.nn.tasks import DetectionModel
from ultralytics.utils import LOGGER, YAML

from .modules import (
    SceneSpecificBatchNorm2d,
    SceneSpecificShallowStem,
    install_shared_dsbn,
)
from .trainer import UnifiedWindTurbineTrainer


class SceneShallowDSBNSharedTrainer(UnifiedWindTurbineTrainer):
    """Isolate DSBN by changing only ordinary shared BN from Experiment 3."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Ultralytics stores the model YAML path in self.model during trainer
        # initialization and only constructs the nn.Module when train() starts.
        # Write a provisional identity here; get_model() overwrites it with the
        # verified numeric DSBN count immediately after model construction.
        self._save_experiment_identity(dsbn_count="pending_model_build")

    def _save_experiment_identity(self, dsbn_count):
        YAML.save(
            self.save_dir / "E4_seed1_experiment_identity.yaml",
            {
                "experiment": "E4_scene_specific_shallow_DSBN_shared_head",
                "land_input": ["B4", "B3", "B2", "B8", "B12", "VV", "VH"],
                "offshore_input": ["B4", "B3", "B2"],
                "stem_P2": "scene-specific; land SG path, offshore RGB path",
                "backbone_P3_P5_and_neck": "shared convolution weights",
                "batch_norm": "DSBN in shared P3-P5 backbone and neck",
                "dsbn_layer_count": dsbn_count,
                "detect_head": "one shared standard YOLOv8 Detect",
                "SG_in_land_shallow": True,
                "PCAS": False,
                "DSBN": True,
                "only_change_from_E3": "ordinary shared BN replaced by DSBN in shared backbone and neck",
            },
        )

    def get_model(self, cfg=None, weights=None, verbose=True):
        model = DetectionModel(cfg, nc=self.data["nc"], ch=7, verbose=verbose)
        if not isinstance(model.model[0], SceneSpecificShallowStem):
            raise TypeError("UniWT-YOLO requires SceneSpecificShallowStem as graph layer 0.")
        if type(model.model[-1]) is not Detect:
            raise TypeError("UniWT-YOLO requires exactly one standard shared Detect head; PCAS/private heads are forbidden.")
        dsbn_count = install_shared_dsbn(model)
        if dsbn_count <= 0:
            raise RuntimeError("UniWT-YOLO failed to install DSBN in the shared backbone/neck.")
        verified_count = sum(isinstance(module, SceneSpecificBatchNorm2d) for module in model.modules())
        if verified_count != dsbn_count:
            raise RuntimeError(
                f"UniWT-YOLO DSBN count mismatch: installer={dsbn_count}, graph={verified_count}."
            )
        self._save_experiment_identity(dsbn_count=int(verified_count))
        if weights:
            model.load(weights)
        LOGGER.info(
            f"UniWT-YOLO graph: scene-specific Stem/P2; {dsbn_count} DSBN layers in shared path; "
            "one shared standard Detect head."
        )
        return model
