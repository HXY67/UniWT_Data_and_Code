"""V4 scene-conditioned unified trainer with DSBN and private heads."""

from __future__ import annotations

import json
import math
import shutil
from copy import copy
from pathlib import Path
from typing import Any

import numpy as np
import torch

from ultralytics.data import build_dataloader, build_yolo_dataset
from ultralytics.models.yolo.detect.train import DetectionTrainer
from ultralytics.models.yolo.detect.val import DetectionValidator
from ultralytics.utils import DEFAULT_CFG, LOCAL_RANK, LOGGER, YAML
from ultralytics.data.utils import check_det_dataset
from ultralytics.utils.torch_utils import torch_distributed_zero_first, unwrap_model

from .data import InterleavedDomainLoader
from .modules import (
    SceneSpecificDetect,
    install_shared_dsbn,
    register_unified_components,
    set_active_scene,
)

register_unified_components()


class UnifiedWindTurbineTrainer(DetectionTrainer):
    """Train one checkpoint with native-size, non-repeating domain batches.

    Land batches are 7-channel 256x256 and offshore batches are 3-channel
    256x256 by default. Every underlying batch is consumed exactly once per
    epoch and both domains are spread across the epoch by normalized progress.
    All batches update one optimizer and one shared detector.
    """

    def __init__(
        self,
        land_data: str | Path,
        offshore_data: str | Path,
        land_imgsz: int = 256,
        offshore_imgsz: int = 256,
        save_first_n_epochs: int = 20,
        cfg=DEFAULT_CFG,
        overrides: dict[str, Any] | None = None,
        _callbacks: dict | None = None,
    ):
        self.land_data_file = str(Path(land_data).resolve())
        self.offshore_data_file = str(Path(offshore_data).resolve())
        self.land_imgsz = int(land_imgsz)
        self.offshore_imgsz = int(offshore_imgsz)
        self.save_first_n_epochs = max(int(save_first_n_epochs), 0)
        self._current_scene: str | None = None
        self._domain_loss_sums: dict[str, torch.Tensor | None] = {"land": None, "offshore": None}
        self._weighted_domain_loss_sums: dict[str, torch.Tensor | None] = {"land": None, "offshore": None}
        self._domain_loss_counts = {"land": 0, "offshore": 0}
        self.domain_loss_weights = {"land": 1.0, "offshore": 1.0}

        for name, size in (("land_imgsz", self.land_imgsz), ("offshore_imgsz", self.offshore_imgsz)):
            if size <= 0 or size % 32:
                raise ValueError(f"{name} must be a positive multiple of 32, got {size}.")

        overrides = dict(overrides or {})
        overrides["data"] = self.land_data_file
        # The base trainer needs one nominal size. Domain datasets receive
        # their own sizes below; using the maximum keeps memory checks honest.
        overrides["imgsz"] = max(self.land_imgsz, self.offshore_imgsz)
        overrides.setdefault("bgr", 0.0)
        overrides.setdefault("hsv_h", 0.0)
        overrides.setdefault("hsv_s", 0.0)
        overrides.setdefault("hsv_v", 0.0)

        super().__init__(cfg=cfg, overrides=overrides, _callbacks=_callbacks)

        if self.ddp or self.world_size > 1:
            raise RuntimeError("UnifiedWindTurbineTrainer V4 supports one GPU only; use device=0.")
        if str(self.args.optimizer).lower() != "sgd":
            raise ValueError(
                "V4 requires optimizer='SGD'. optimizer='auto' may select MuSGD and is forbidden."
            )
        if not math.isclose(float(self.args.lr0), 0.005, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError(f"V4 requires lr0=0.005, got {self.args.lr0}.")
        guarded_augmentations = {
            "mosaic": float(self.args.mosaic),
            "multi_scale": float(self.args.multi_scale),
            "scale": float(self.args.scale),
            "translate": float(self.args.translate),
        }
        nonzero = {key: value for key, value in guarded_augmentations.items() if value != 0.0}
        if nonzero:
            raise ValueError(f"V4 forbids Mosaic and secondary scale/translation augmentation, got {nonzero}.")

        self.land_data = self.data
        with torch_distributed_zero_first(LOCAL_RANK):
            self.offshore_data = check_det_dataset(self.offshore_data_file)
        self._validate_domain_definitions()

        self.add_callback("on_train_epoch_start", self._reset_domain_loss_callback)
        self.add_callback("on_train_batch_end", self._collect_domain_loss_callback)

        YAML.save(
            self.save_dir / "domain_data.yaml",
            {
                "version": "4.0",
                "land_data": self.land_data_file,
                "offshore_data": self.offshore_data_file,
                "land_channels": 7,
                "offshore_channels": 3,
                "land_imgsz": self.land_imgsz,
                "offshore_imgsz": self.offshore_imgsz,
                "land_band_order": ["B4", "B3", "B2", "B8", "B12", "VV", "VH"],
                "offshore_band_order": ["B4", "B3", "B2"],
                "sampling": "non-repeating proportional interleave; each underlying batch once per epoch",
                "architecture": (
                    "scene-specific Stem/P2; shared P3-P5 and neck convolution; "
                    "DSBN in shared path; land PCAS head; offshore standard YOLOv8 head"
                ),
                "domain_balance": "w_d=C/sqrt(N_d), C=(N_land+N_offshore)/(sqrt(N_land)+sqrt(N_offshore))",
                "optimizer": "SGD (explicit; MuSGD forbidden)",
                "checkpoint_selection": "mean of land and offshore validation fitness",
                "early_stopping_patience": int(self.args.patience),
                "save_first_n_epochs": self.save_first_n_epochs,
            },
        )

    def _validate_domain_definitions(self) -> None:
        land_channels = int(self.land_data.get("channels", 3))
        offshore_channels = int(self.offshore_data.get("channels", 3))
        if land_channels != 7:
            raise ValueError(f"Land data YAML must declare channels: 7, got {land_channels}.")
        if offshore_channels != 3:
            raise ValueError(f"Offshore data YAML must declare channels: 3, got {offshore_channels}.")
        if self.land_data["nc"] != self.offshore_data["nc"]:
            raise ValueError("Land and offshore datasets must have the same number of classes.")
        if self.land_data["names"] != self.offshore_data["names"]:
            raise ValueError("Land and offshore data YAML files must use identical class names and IDs.")
        if bool(self.offshore_data.get("preserve_channel_order", False)):
            raise ValueError(
                "The supplied offshore data are single-page RGB TIFFs. Set preserve_channel_order: false so OpenCV BGR "
                "is converted to Sentinel-2 RGB [B4, B3, B2]."
            )

    def get_model(self, cfg: str | None = None, weights: str | None = None, verbose: bool = True):
        # DSBN must exist before loading a V4 checkpoint; otherwise its two BN
        # state dictionaries would not match a freshly parsed ordinary BN graph.
        from ultralytics.nn.tasks import DetectionModel

        model = DetectionModel(
            cfg,
            nc=self.data["nc"],
            ch=self.data["channels"],
            verbose=verbose,
        )
        if model.model[0].__class__.__name__ != "SceneSpecificShallowStem":
            raise TypeError("V4 requires SceneSpecificShallowStem as graph layer 0.")
        if not isinstance(model.model[-1], SceneSpecificDetect):
            raise TypeError("V4 requires SceneSpecificDetect as the last graph layer.")
        dsbn_count = install_shared_dsbn(model)
        if dsbn_count <= 0:
            raise RuntimeError("V4 did not install any DSBN layers in the shared graph.")
        if weights:
            model.load(weights)
        LOGGER.info(f"V4 installed {dsbn_count} DSBN layers in shared P3-P5 backbone and neck.")
        return model

    def _build_domain_loader(
        self,
        data: dict,
        dataset_path,
        batch_size: int,
        rank: int,
        mode: str,
        imgsz: int,
    ):
        if mode not in {"train", "val"}:
            raise ValueError(f"Unsupported loader mode: {mode}")
        domain_args = copy(self.args)
        domain_args.imgsz = int(imgsz)
        grid_size = max(int(unwrap_model(self.model).stride.max()), 32)
        with torch_distributed_zero_first(rank):
            dataset = build_yolo_dataset(
                domain_args,
                dataset_path,
                batch_size,
                data,
                mode=mode,
                rect=mode == "val",
                stride=grid_size,
            )
        shuffle = mode == "train"
        if getattr(dataset, "rect", False) and shuffle and not np.all(dataset.batch_shapes == dataset.batch_shapes[0]):
            LOGGER.warning("'rect=True' is incompatible with shuffle; disabling shuffle for this domain.")
            shuffle = False
        return build_dataloader(
            dataset,
            batch=batch_size,
            workers=self.args.workers if mode == "train" else self.args.workers * 2,
            shuffle=shuffle,
            rank=rank,
            drop_last=self.args.compile and mode == "train",
        )

    def _build_train_pipeline(self) -> None:
        """Build native-size loaders, non-repeating interleave, optimizer and scheduler."""
        batch_size = self.batch_size // max(self.world_size, 1)
        self.land_train_loader = self._build_domain_loader(
            self.land_data,
            self.land_data["train"],
            batch_size=batch_size,
            rank=LOCAL_RANK,
            mode="train",
            imgsz=self.land_imgsz,
        )
        self.offshore_train_loader = self._build_domain_loader(
            self.offshore_data,
            self.offshore_data["train"],
            batch_size=batch_size,
            rank=LOCAL_RANK,
            mode="train",
            imgsz=self.offshore_imgsz,
        )
        self.train_loader = InterleavedDomainLoader(self.land_train_loader, self.offshore_train_loader)
        land_batches = len(self.land_train_loader)
        offshore_batches = len(self.offshore_train_loader)
        total_batches = land_batches + offshore_batches
        # Square-root balancing is deliberately milder than strict 1:1
        # balancing. The mean batch weight remains exactly 1.0, while the
        # offshore domain receives more influence without suppressing the
        # larger land domain as strongly as inverse-frequency weighting.
        normalizer = total_batches / (math.sqrt(land_batches) + math.sqrt(offshore_batches))
        self.domain_loss_weights = {
            "land": normalizer / math.sqrt(land_batches),
            "offshore": normalizer / math.sqrt(offshore_batches),
        }
        YAML.save(
            self.save_dir / "E4_seed2_domain_balance.yaml",
            {
                "strategy": "square_root",
                "formula": "w_d=C/sqrt(N_d), C=(N_land+N_offshore)/(sqrt(N_land)+sqrt(N_offshore))",
                "land_batches": land_batches,
                "offshore_batches": offshore_batches,
                "land_loss_weight": self.domain_loss_weights["land"],
                "offshore_loss_weight": self.domain_loss_weights["offshore"],
                "weighted_mean_check": (
                    land_batches * self.domain_loss_weights["land"]
                    + offshore_batches * self.domain_loss_weights["offshore"]
                ) / total_batches,
            },
        )

        # Use the same 256 px protocol for land and offshore validation.
        val_batch = batch_size
        self.land_test_loader = self._build_domain_loader(
            self.land_data,
            self.land_data.get("val") or self.land_data.get("test"),
            batch_size=val_batch,
            rank=LOCAL_RANK,
            mode="val",
            imgsz=self.land_imgsz,
        )
        self.offshore_test_loader = self._build_domain_loader(
            self.offshore_data,
            self.offshore_data.get("val") or self.offshore_data.get("test"),
            batch_size=val_batch,
            rank=LOCAL_RANK,
            mode="val",
            imgsz=self.offshore_imgsz,
        )
        self.test_loader = self.land_test_loader

        self.accumulate = max(round(self.args.nbs / self.batch_size), 1)
        weight_decay = self.args.weight_decay * self.batch_size * self.accumulate / self.args.nbs
        iterations = math.ceil(len(self.train_loader.dataset) / max(self.batch_size, self.args.nbs)) * self.epochs
        self.optimizer = self.build_optimizer(
            model=self.model,
            name="SGD",
            lr=self.args.lr0,
            momentum=self.args.momentum,
            decay=weight_decay,
            iterations=iterations,
        )
        self._setup_scheduler()

        if self.validator is not None:
            self.validator = self.get_validator()

        LOGGER.info(
            "V4 square-root-balanced domain schedule: "
            f"land={len(self.land_train_loader)} batches @ {self.land_imgsz}px, "
            f"offshore={len(self.offshore_train_loader)} batches @ {self.offshore_imgsz}px, "
            f"epoch={len(self.train_loader)} batches, repeats=0; "
            f"loss weights land={self.domain_loss_weights['land']:.4f}, "
            f"offshore={self.domain_loss_weights['offshore']:.4f}."
        )

    def preprocess_batch(self, batch: dict) -> dict:
        scene = batch.get("scene")
        if scene not in {"land", "offshore"}:
            raise ValueError(f"Training batch is missing a valid scene tag: {scene!r}")
        expected_size = self.land_imgsz if scene == "land" else self.offshore_imgsz
        if tuple(batch["img"].shape[-2:]) != (expected_size, expected_size):
            raise ValueError(
                f"{scene} batch has spatial shape {tuple(batch['img'].shape[-2:])}; expected "
                f"({expected_size}, {expected_size})."
            )
        self._current_scene = scene
        set_active_scene(scene)
        batch["domain_loss_weight"] = self.domain_loss_weights[scene]
        return super().preprocess_batch(batch)

    @staticmethod
    def _reset_domain_loss_callback(trainer) -> None:
        trainer._domain_loss_sums = {"land": None, "offshore": None}
        trainer._weighted_domain_loss_sums = {"land": None, "offshore": None}
        trainer._domain_loss_counts = {"land": 0, "offshore": 0}

    @staticmethod
    def _collect_domain_loss_callback(trainer) -> None:
        scene = trainer._current_scene
        if scene not in trainer._domain_loss_sums:
            return
        values = trainer.loss_items.detach().float().cpu()
        if trainer._domain_loss_sums[scene] is None:
            trainer._domain_loss_sums[scene] = values.clone()
        else:
            trainer._domain_loss_sums[scene] += values
        weighted_values = values * trainer.domain_loss_weights[scene]
        if trainer._weighted_domain_loss_sums[scene] is None:
            trainer._weighted_domain_loss_sums[scene] = weighted_values.clone()
        else:
            trainer._weighted_domain_loss_sums[scene] += weighted_values
        trainer._domain_loss_counts[scene] += 1

    def _domain_loss_metrics(self) -> dict[str, float]:
        names = ("box_loss", "cls_loss", "dfl_loss")
        output: dict[str, float] = {}
        for scene in ("land", "offshore"):
            count = self._domain_loss_counts[scene]
            sums = self._domain_loss_sums[scene]
            if count <= 0 or sums is None:
                values = [float("nan")] * len(names)
            else:
                values = (sums / count).tolist()
            output.update({f"{scene}/train/{name}": float(value) for name, value in zip(names, values)})
            weighted_sums = self._weighted_domain_loss_sums[scene]
            if count <= 0 or weighted_sums is None:
                weighted_values = [float("nan")] * len(names)
            else:
                weighted_values = (weighted_sums / count).tolist()
            output.update(
                {f"{scene}/train/weighted_{name}": float(value) for name, value in zip(names, weighted_values)}
            )
        return output

    def get_validator(self):
        """Create one validator per native-size domain."""
        self.loss_names = "box_loss", "cls_loss", "dfl_loss"
        land_args = copy(self.args)
        land_args.data = self.land_data_file
        land_args.imgsz = self.land_imgsz
        offshore_args = copy(self.args)
        offshore_args.data = self.offshore_data_file
        offshore_args.imgsz = self.offshore_imgsz

        self.land_validator = DetectionValidator(
            self.land_test_loader,
            save_dir=self.save_dir / "val_land",
            args=land_args,
            _callbacks=self.callbacks,
        )
        self.offshore_validator = DetectionValidator(
            self.offshore_test_loader,
            save_dir=self.save_dir / "val_offshore",
            args=offshore_args,
            _callbacks=self.callbacks,
        )
        return self.land_validator

    def _run_domain_validation(self, validator: DetectionValidator, data: dict) -> dict[str, float]:
        original_data = self.data
        self.data = data
        try:
            result = validator(self)
        finally:
            self.data = original_data
        return {} if result is None else dict(result)

    @staticmethod
    def _combine_metrics(land: dict[str, float], offshore: dict[str, float]) -> dict[str, float]:
        combined = {f"land/{key}": value for key, value in land.items()}
        combined.update({f"offshore/{key}": value for key, value in offshore.items()})
        for key, short_name in (
            ("metrics/precision(B)", "precision(B)"),
            ("metrics/recall(B)", "recall(B)"),
            ("metrics/mAP50(B)", "mAP50(B)"),
            ("metrics/mAP50-95(B)", "mAP50-95(B)"),
        ):
            if key in land and key in offshore:
                combined[f"macro/{short_name}"] = (float(land[key]) + float(offshore[key])) / 2.0
        return combined

    def validate(self):
        """Validate both domains and append domain-specific training losses."""
        land_metrics = self._run_domain_validation(self.land_validator, self.land_data)
        offshore_metrics = self._run_domain_validation(self.offshore_validator, self.offshore_data)
        if not land_metrics or not offshore_metrics:
            return None, None

        fallback = -float(self.loss.detach().cpu())
        land_fitness = float(land_metrics.pop("fitness", fallback))
        offshore_fitness = float(offshore_metrics.pop("fitness", fallback))
        fitness = (land_fitness + offshore_fitness) / 2.0
        metrics = self._combine_metrics(land_metrics, offshore_metrics)
        metrics.update(self._domain_loss_metrics())
        metrics["macro/fitness"] = fitness
        if self.best_fitness is None or self.best_fitness < fitness:
            self.best_fitness = fitness
        LOGGER.info(
            f"V4 domain fitness: land={land_fitness:.5f}, offshore={offshore_fitness:.5f}, macro={fitness:.5f}"
        )
        return metrics, fitness

    def save_model(self):
        """Save stock checkpoints plus epoch001--epoch020 diagnostic snapshots."""
        super().save_model()
        epoch_number = self.epoch + 1
        if epoch_number <= self.save_first_n_epochs and self.last.exists():
            shutil.copyfile(self.last, self.wdir / f"epoch{epoch_number:03d}.pt")

    def final_eval(self) -> None:
        """Run final native-size evaluations and write a dual-domain report."""
        super().final_eval()
        if not self.best.exists():
            return
        self.offshore_validator.args.plots = self.args.plots
        self.offshore_validator.args.compile = False
        offshore_metrics = dict(self.offshore_validator(model=self.best))
        offshore_metrics.pop("fitness", None)
        land_metrics = dict(self.metrics or {})
        combined = self._combine_metrics(land_metrics, offshore_metrics)
        report = {
            "checkpoint": str(self.best),
            "land_imgsz": self.land_imgsz,
            "offshore_imgsz": self.offshore_imgsz,
            "land": land_metrics,
            "offshore": offshore_metrics,
            "macro": {key.removeprefix("macro/"): value for key, value in combined.items() if key.startswith("macro/")},
        }
        report_path = self.save_dir / "E4_seed1_final_domain_metrics.json"
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        LOGGER.info(f"Saved V4 dual-domain final metrics to {report_path}")
